package com.example.newsapp

const val BASE_URL="https://newsapi.org/v2/"