package com.example.newsapp.network

import retrofit2.Response
import retrofit2.http.Query

annotation class GET(val value: String)

interface ApiService {


    @GET("top-headlines")
    suspend fun getNewsFromServer(
        @Query("country")country:String="in",
        @Query("sortBy")sortBy:String="us&category=business",
       @Query("apiKey")apikey:String="f3ea699106ee4a4082eab190d8cfd3d0"
    ): Response<NewsModel>
}