package com.example.newsapp.screen

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsapp.network.NewsModel
import com.example.newsapp.repo.Repo
import com.example.newsapp.screen.Result
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.launch
import java.lang.Exception


class NewsViewModel(): ViewModel () {
   var res=  mutableStateOf<NewsModel?>(null)

    init {
          viewModelScope.launch {
             res.value= getNews(Repo())
          }

      }
    suspend fun getNews(repo: Repo):NewsModel?{
        return repo.newProvider().body()
      }


      }
