package com.example.newsapp.network

data class Source(
    val id: String,
    val name: String
)